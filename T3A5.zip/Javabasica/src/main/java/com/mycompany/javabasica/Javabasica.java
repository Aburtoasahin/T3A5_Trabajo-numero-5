

package com.mycompany.javabasica; //paquete de codigo fuente

/**
 *
 * @author Asahin Aburto Brigido
 */
public class Javabasica { //Aqui se declara la clase 
    //Variable global de tipo String
    private static String nombre = "Asahin"; 

    public static void main(String[] args) {   //Metodo main
        
        //Variable local de tipo String
        String apellidos = "Aburto Brigido"
        
        // Imprime un mensaje en pantalla 
        System.out.println("hola mundo Java");
        System.out.print( "Nombre" + nombre + " " + apellidos + "\n");
    }
}
